#include "game.h"
#include "music.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include "ledmatrix.h"
#include "terminalio.h"

extern uint32_t get_current_time(void);

// ============================ GLOBAL VARIABLES =============================
// Game board --> dynamically constructed by initialise_game() --> updated throughout game.
// 0th element of array = bottom row.
// 7th element of array = top row.
uint8_t board[MATRIX_NUM_ROWS][MATRIX_NUM_COLUMNS];

uint8_t (*get_board(void))[MATRIX_NUM_COLUMNS] {
    return board;
}

// Player location.
uint8_t player_row;
uint8_t player_col;

// Flag --> keep track of player visibility.
static bool player_visible;
extern bool is_muted;

// ============================ UNDO/REDO THINGS =============================
movement last_redo_move;
movement stack_of_moves[6];
movement redo_stack[6];

uint8_t stack_of_moves_size = 0;
uint8_t redo_stack_size = 0;
uint8_t undo_index = 0;
bool was_box_shoved = false;

// ========================== GAME LOGIC FUNCTIONS ===========================
// Paints a square based on the object(s) currently on it.
static void paint_square(uint8_t row, uint8_t col)
{
	switch (board[row][col] & OBJECT_MASK)
	{
		case ROOM: ledmatrix_update_pixel(row, col, COLOUR_BLACK); break;
		case WALL: ledmatrix_update_pixel(row, col, COLOUR_WALL); break;
		case BOX: ledmatrix_update_pixel(row, col, COLOUR_BOX); break;
		case TARGET: ledmatrix_update_pixel(row, col, COLOUR_TARGET); break;
		case BOX | TARGET: ledmatrix_update_pixel(row, col, COLOUR_DONE); break;
		default: break;
	}

	// Update terminal view to match LED matrix exactly.
	// Make sure to invert terminal rows relative to LED matrix.
	// All colours standardised --> let box = BG_WHITE.
    move_terminal_cursor((MATRIX_NUM_ROWS - row) + 5, col * 2 + 1);
	uint8_t object = board[row][col] & OBJECT_MASK;
	switch (object) {
		case ROOM: set_display_attribute(BG_BLACK); break;
		case WALL: set_display_attribute(BG_YELLOW); break;
		case BOX: set_display_attribute(BG_WHITE); break;
		case TARGET: set_display_attribute(BG_RED); break;
		case BOX | TARGET: set_display_attribute(BG_GREEN); break;
		default: break;
	}
	// Print two spaces for less squash.
	printf("  ");
    normal_display_mode(); 
}

// Initialises global variables.
void initialise_game(uint8_t level)
{
	// Short definitions of game objects used temporarily for game layout.
	#define _	(ROOM)
	#define W	(WALL)
	#define T	(TARGET)
	#define B	(BOX)

	// The starting layout of level 1.
	// Top row = 0th row.
	// Bottom row = 7th row.
	// LED matrix treats bottom row (row 0) and top row (row 7) --> flipped.
	static const uint8_t lv1_layout[MATRIX_NUM_ROWS][MATRIX_NUM_COLUMNS] =
	{
		{ _, W, _, W, W, W, _, W, W, W, _, _, W, W, W, W },
		{ _, W, T, W, _, _, W, T, _, B, _, _, _, _, T, W },
		{ _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _ },
		{ W, _, B, _, _, _, _, W, _, _, B, _, _, B, _, W },
		{ W, _, _, _, W, _, B, _, _, _, _, _, _, _, _, _ },
		{ _, _, _, _, _, _, T, _, _, _, _, _, _, _, _, _ },
		{ _, _, _, W, W, W, W, W, W, T, _, _, _, _, _, W },
		{ W, W, _, _, _, _, _, _, W, W, _, _, W, W, W, W }
	};

    // Level 2 layout --> super tedious to do. Also makesure player is in top right.
    // Do not flip the row for the since the bottom is actually row 0.
    static const uint8_t lv2_layout[MATRIX_NUM_ROWS][MATRIX_NUM_COLUMNS] =
	{
		{ _, _, W, W, W, W, _, _, W, W, _, _, _, _, _, W },
		{ _, _, W, _, _, W, _, W, W, _, _, _, _, B, _, _ },
		{ _, _, W, _, B, W, W, W, _, _, T, W, _, T, W, W },
		{ _, _, W, _, _, _, _, T, _, _, B, W, W, W, _, W },
		{ W, W, W, W, _, W, _, _, _, _, _, W, _, W, W, _ },
		{ W, T, B, _, _, _, _, B, _, _, _, W, W, _, W, W },
		{ W, _, _, _, T, _, _, _, _, _, _, B, T, _, _, _ },
		{ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W, W }
	};

	// Undefine short game object names defined above --> I cannot use them in my code.
	// Use of single-letter names/constants is never a good idea.
	#undef _
	#undef W
	#undef T
	#undef B

    if (level==1){
        // Set initial player location (level 1) --> handy logic since it helps in level 2 player initialisation.
        player_row = 5;
        player_col = 2;

        // Make player icon initially invisible.
        player_visible = false;

        // Copy starting layout (level 1 map) to board array --> flip all rows.
        for (uint8_t row = 0; row < MATRIX_NUM_ROWS; row++)
        {
            for (uint8_t col = 0; col < MATRIX_NUM_COLUMNS; col++)
            {
                board[MATRIX_NUM_ROWS - 1 - row][col] =
                    lv1_layout[row][col];
            }
        }

        // Draw game board (map).
        for (uint8_t row = 0; row < MATRIX_NUM_ROWS; row++)
        {
            for (uint8_t col = 0; col < MATRIX_NUM_COLUMNS; col++)
            {
                paint_square(row, col);
            }
        }
    } else {
        // Basically since there are only two levels, if they aren't on level one, then they are on level 2. 
        player_row = 6;
        player_col = 15;
        player_visible = false;

        // Super similar to level 1, nothing really new here.
        for (uint8_t row = 0; row < MATRIX_NUM_ROWS; row++)
        {
            for (uint8_t col = 0; col < MATRIX_NUM_COLUMNS; col++)
            {
                board[MATRIX_NUM_ROWS - 1 - row][col] =
                    lv2_layout[row][col];
            }
        }

        // Call paint_square() for each cell --> initialise game board for lvl 2.
        for (uint8_t row = 0; row < MATRIX_NUM_ROWS; row++)
        {
            for (uint8_t col = 0; col < MATRIX_NUM_COLUMNS; col++)
            {
                paint_square(row, col);
            }
        }
    }
}

void load_game(uint8_t row, uint8_t col, levelstruct* lvl)
{
    player_row = row;
    player_col = col;
    
    player_visible = false;

    for (uint8_t row = 0; row < MATRIX_NUM_ROWS; row++)
    {
        for (uint8_t col = 0; col < MATRIX_NUM_COLUMNS; col++)
        {
            board[row][col] = lvl->board[row][col];
        }
    }

    for (uint8_t row = 0; row < MATRIX_NUM_ROWS; row++)
    {
        for (uint8_t col = 0; col < MATRIX_NUM_COLUMNS; col++)
        {
            paint_square(row, col);
        }
    }
    
}

void initialise_lights(void){
    DDRA |= 0b11111100;
}

// Repeating level 1 initialisation logic. 
void initialize_level_2(void){
	#define _	(ROOM)
	#define W	(WALL)
	#define T	(TARGET)
	#define B	(BOX)

    // Undefine short game object names defined above --> I cannot use them in my code.
	// Use of single-letter names/constants is never a good idea.
	#undef _
	#undef W
	#undef T
	#undef B
}

// If icon is currently visible --> it is set to not visible and removed from display.
// If icon is currenty invisible --> it is set to visible and rendered on display.
// Static global variable "player_visible" indicates whether player icon is currently visible.
void flash_player(void)
{
	player_visible = !player_visible;
	if (player_visible)
	{
		// Player visible --> paint with COLOUR_PLAYER.
		ledmatrix_update_pixel(player_row, player_col, COLOUR_PLAYER);

		// Update terminal for player.
        // `+5` adjusts whole terminal down to make room for messages and timer.
        move_terminal_cursor((MATRIX_NUM_ROWS - player_row) + 5, player_col * 2 + 1);
        set_display_attribute(BG_CYAN);  // Player colour --> I selected cyan.
        printf("  ");  // Draw player non-compressed.
        normal_display_mode(); // Basically reset --> this fixed the cyan error I had which unintentionally coloured my terminal cyan.
	}
	else
	{
		// Player not visible --> paint underlying square (hide player).
		paint_square(player_row, player_col);
	}
}

static uint32_t last_flash_for_target_time = 0;
static bool target_visibility = true;

void flash_targets(void) {
    uint32_t current_time = get_current_time();
    if ((current_time - last_flash_for_target_time) >= 500) {
        target_visibility = !target_visibility;
        for (uint8_t row = 0; row < MATRIX_NUM_ROWS; row++) {
            for (uint8_t col = 0; col < MATRIX_NUM_COLUMNS; col++) {
                if (board[row][col] & TARGET) {
                    if (board[row][col] & BOX) {
                    continue;
                    }
                    else if (player_row == row && player_col == col) {
                        continue;
                    }
                    move_terminal_cursor((MATRIX_NUM_ROWS - row) + 5, col * 2 + 1);
                    if (target_visibility) {
                        set_display_attribute(BG_RED);
                        ledmatrix_update_pixel(row, col, COLOUR_TARGET); // Show red.
                    }
                    else {
                        ledmatrix_update_pixel(row, col, COLOUR_BLACK); // Show black.
                        set_display_attribute(BG_BLACK);
                    }
                    printf("  ");
                    normal_display_mode();
                }
            }
        }
        last_flash_for_target_time = current_time;
    } 
}

// Helper function to determine if move is valid (i.e, no wall).
// Reference (board[row][col] & OBJECT_MASK) above.
bool valid_move(int8_t delta_col, int8_t delta_row) {
    // Check if next player position has wall.
	// Invalid move = if target is wall; Valid move = if target is not wall.
    int8_t new_row = (player_row + delta_row + MATRIX_NUM_ROWS) % MATRIX_NUM_ROWS;
    int8_t new_col = (player_col + delta_col + MATRIX_NUM_COLUMNS) % MATRIX_NUM_COLUMNS;
    
    if (board[new_row][new_col] == WALL) {
        return false;
    }

    if (delta_row != 0 && delta_col != 0) {
        if (board[new_row][player_col] == WALL && board[player_row][new_col] == WALL){
            return false;
        }
        if (board[new_row][new_col] == BOX){
            return false;
        }
        return true; // Yes movement.
    }
    return true; // Yes movement.
}

// Helper function for message generation.
// Teehee silly messages :3.
// Actual RAM eating monstrosity.
void random_messages(void) {
    const char* messages[] = {
        "Please refrain from hitting the wall.",
        "Pro tip: You can't phase through walls.",
        "Friendly advice: The wall won't budge."
    };
	// rand() % 3 ensures random index 0, 1, or 2 --> corresponds to 3 different array messages.
    printf(("%s\n"), messages[rand() % 3]);
}

// I love how unnecessary this single helper funciton is lmao.
void diagonal_box_message(void){
    printf(PSTR("Boxes cannot be pushed on the diagonal!"));
}

uint8_t animation_box_row = 69;
uint8_t animation_box_col = 66;
uint16_t animation_where_I_am_up_to = 6000;
uint16_t the_current_animation_colour = 0b11110000;

void stop_fun_box_animation(void){
    animation_where_I_am_up_to = 0b1111111111111111;
    animation_box_row = 69;
    animation_box_col = 66;
}

static bool playing_animation = false;


void start_fun_box_animation(uint8_t stupid_animation_box_row, uint8_t stupid_animation_box_col){
    if (playing_animation)
    {
        ledmatrix_update_pixel(animation_box_row, animation_box_col, COLOUR_DONE);
        stop_fun_box_animation();
    }

    playing_animation = true;

    animation_box_row = stupid_animation_box_row;
    animation_box_col = stupid_animation_box_col;
    animation_where_I_am_up_to = 0;
}

void do_animation(){
    if (animation_where_I_am_up_to > 1000){
        playing_animation = false;
        return;
    }

    if (animation_where_I_am_up_to == 1000 ) {
        ledmatrix_update_pixel(animation_box_row, animation_box_col, COLOUR_DONE);
        stop_fun_box_animation();
        return;
    }

    the_current_animation_colour ^= 0b1111111111111111;
    ledmatrix_update_pixel(animation_box_row, animation_box_col, the_current_animation_colour);
    animation_where_I_am_up_to++;
}

// Helper function for box game logic.
// Take inspiration for wrapping and general movement from move_player.
// I used beta_row and beta_col so I don't confuse myself with delta_row and delta_col in player_move function.
// This function logic works but it could have been better handled --> very techy logic with move_player.
void box_movement(int8_t box_row, int8_t box_col, int8_t beta_row, int8_t beta_col) {
    // Box row wrapping.
    int8_t next_box_row = box_row + beta_row;
	if (next_box_row < 0) {
		next_box_row = (next_box_row + MATRIX_NUM_ROWS) % MATRIX_NUM_ROWS;
	} else if (next_box_row >= MATRIX_NUM_ROWS) {
	next_box_row = next_box_row % MATRIX_NUM_ROWS;
	}

	// Box column wrapping.
	int8_t next_box_col = box_col + beta_col;
	if (next_box_col < 0) {
		next_box_col = (next_box_col + MATRIX_NUM_COLUMNS) % MATRIX_NUM_COLUMNS;
	} else if (next_box_col >= MATRIX_NUM_COLUMNS) {
	next_box_col = next_box_col % MATRIX_NUM_COLUMNS;
	}

    // Case 1: Square in-front of box is free (no wall or box).
    if ((board[next_box_row][next_box_col] & (WALL | BOX)) == ROOM) {

        // Inversion (all 0's) and 'ANDING' with 0 clears box from current position (bit-masking).
        board[box_row][box_col] &= ~BOX;

		// 'ORING' (all 1's) will place box in new location (bit-masking).
        board[next_box_row][next_box_col] |= BOX;

        // Check if box is on target.
        // PP: I had to move a lot of the other messages into the move_player to accomodate for future dependencies.
        if (board[next_box_row][next_box_col] & TARGET) {
            start_fun_box_animation(next_box_row, next_box_col);
            move_terminal_cursor(1, 1);
            clear_to_end_of_line();
            printf_P(PSTR("Yippie! The box has been moved onto a target!\n"));
            normal_display_mode(); 

            // Play the 'ding' sound if not muted.
            if (!is_muted) {
                setting_melody(ding_melody, ding_melody_length, false);
                resume_music();
            }
        }

 		// If valid --> erase current player position (directly erasing for no ghost players).
        paint_square(player_row, player_col);

		// Update player position to new position (where box was previously).
        player_row = box_row;
        player_col = box_col;
        
        player_visible = true;
        ledmatrix_update_pixel(player_row, player_col, COLOUR_PLAYER);

        // Update terminal for player.
        // `+5` adjusts whole terminal down to make room for messages and timer.
        move_terminal_cursor((MATRIX_NUM_ROWS - player_row) + 5, player_col * 2 + 1);
        set_display_attribute(BG_CYAN);  // Player colour --> I selected cyan.
        printf("  ");  // Draw player non-compressed.
        normal_display_mode(); // Basically reset --> this fixed the cyan error I had which unintentionally coloured my terminal cyan.
		// Showing new box position after being moved.
		paint_square(next_box_row, next_box_col);
    }
}

// Helpfer function to update SSD --> called every 1ms from play_game().
// Take a lot of inspiration from stopwatch lab code --> there are differenecs:
// Differences: Port D2 for CC, Port C instead of Port A, different units, no decimal point.
// Legitimiately worst part of the entire game is the SSD; actual cancer.

static uint8_t seven_seg_cc = 0;

void update_ssd_display(uint8_t count)
{   
    uint8_t seven_seg_data[10] = {63, 6, 91, 79, 102, 109, 125, 7, 127, 111};
    seven_seg_cc ^= 1;
    if (seven_seg_cc == 0) // Tens place (left SSD).
    {
        PORTC = seven_seg_data[(count / 10) % 10];
        PORTD |= (1 << PD2); // Set PD2 high --> left digit shown.
    }
    else
    {
        PORTC = seven_seg_data[count % 10];
        PORTD &= ~(1 << PD2); // Set PD2 low --> right digit shown.
    }
}


bool redo_moves(bool* was_diagonal)
{
    if (redo_stack_size <= 0) {
		return false;
	}
    movement last_move = redo_stack[--redo_stack_size];
    *was_diagonal = last_move.was_diagonal;
    last_redo_move = last_move;
    move_player(last_move.delta_row, last_move.delta_col);
    return true;
}


// ============================ UNDO!!!! =============================
// Function to perform an undo operation.
bool undo_moves(bool* was_diagonal) {
	if (stack_of_moves_size == 0) {
		return false;
	}

	movement last_move = stack_of_moves[--stack_of_moves_size];
    store_in_redo_stack(last_move);
    *was_diagonal = last_move.was_diagonal;
	paint_square(player_row, player_col);

	int8_t the_og_box_row = player_row;
	int8_t the_og_box_col = player_col;
	
	int8_t next_col = player_col - last_move.delta_col;
    if (next_col < 0) {
        next_col = (next_col + MATRIX_NUM_COLUMNS) % MATRIX_NUM_COLUMNS;
    } else if (next_col >= MATRIX_NUM_COLUMNS) {
        next_col = next_col % MATRIX_NUM_COLUMNS;
    }
    player_col = next_col;

    int8_t next_row = player_row - last_move.delta_row;
    if (next_row < 0) {
        next_row = (next_row + MATRIX_NUM_ROWS) % MATRIX_NUM_ROWS;
    } else if (next_row >= MATRIX_NUM_ROWS) {
        next_row = next_row % MATRIX_NUM_ROWS;
    }
    player_row = next_row;

	if (last_move.was_box_shoved) {
        int8_t new_target_row = the_og_box_row + last_move.delta_row;
        if (new_target_row < 0) {
            new_target_row = (new_target_row + MATRIX_NUM_ROWS) % MATRIX_NUM_ROWS;
        } else if (new_target_row >= MATRIX_NUM_ROWS) {
            new_target_row = new_target_row % MATRIX_NUM_ROWS;
        }

        int8_t new_target_col = the_og_box_col + last_move.delta_col;
        if (new_target_col < 0) {
            new_target_col = (new_target_col + MATRIX_NUM_COLUMNS) % MATRIX_NUM_COLUMNS;
        } else if (new_target_col >= MATRIX_NUM_COLUMNS) {
            new_target_col = new_target_col % MATRIX_NUM_COLUMNS;
        }
        board[the_og_box_row][the_og_box_col] |= BOX;
        board[new_target_row][new_target_col] &= ~BOX;
        paint_square(new_target_row, new_target_col);
	}
    paint_square(the_og_box_row, the_og_box_col);
	return true;
}

void store_move_int0_stack(int8_t delta_row, int8_t delta_col, bool was_box_shoved, bool was_diagonal) {
    movement new_move;
    new_move.delta_row = delta_row;
    new_move.delta_col = delta_col;
    new_move.was_box_shoved = was_box_shoved;
    new_move.was_diagonal = was_diagonal;

    if (stack_of_moves_size < 6) {  // Ensure stack doesn't overflow.
        stack_of_moves[stack_of_moves_size] = new_move;
        stack_of_moves_size++;
    } else {
        for (int i = 1; i < 6; i++) {
            stack_of_moves[i - 1] = stack_of_moves[i];
        }
        stack_of_moves[5] = new_move;
    }
}


void store_in_redo_stack(movement move)
{
    if (redo_stack_size < 6) {
        redo_stack[redo_stack_size] = move;
        redo_stack_size++;
    } else {
        for (int i = 1; i < 6; i++) {
            redo_stack[i - 1] = redo_stack[i];
        }
        redo_stack[5] = move;
    }
}

void light_updating(void){
    uint8_t sixz_lights = 0;
    for (uint8_t i = 0; i < stack_of_moves_size; i++) {
        sixz_lights |= (1 << (i + 2));
    }
    PORTA = sixz_lights;
}

// I decided against making a helper function for wrap around since it is not intuitive for me.
// MATRIX_NUM_ROWS = 8 (0 to 7), MATRIX_NUM_COLUMNS = 16 (0 to 15) --> defined in ledmatrix.h.
// Top Row = 0th; Bottom Row = 7th.
// For wall game logic, I am modifying code to include next_col and next_row.
// Changed move_player return type to bool from void.
bool move_player(int8_t delta_row, int8_t delta_col)
{
    if (delta_row != last_redo_move.delta_row && delta_col != last_redo_move.delta_col)
    {
        redo_stack_size = 0;
        last_redo_move.delta_col = 100;
        last_redo_move.delta_row = 100;
    }

    bool was_diagonal = false;
	// PP: It wasn't clearing the previous player position well (I would end up with ghost players).
	// PP: To rectify --> I just directly erased the previous position.
	paint_square(player_row, player_col);
    move_terminal_cursor(1, 1);
    clear_to_end_of_line();

    // Row Wrapping:
	/* 
	Example: player_row = 3; delta_row = -4.
	player_row = 3 + (-4) = -1 (Above top row --> we must move to bottom row).
	player_row = (-1 + 8) % 8 = 7 % 8 = 7 (Moved to 7th row --> bottom row).
	*/
	int8_t next_row = player_row + delta_row;
    if (next_row < 0) {
        next_row = (next_row + MATRIX_NUM_ROWS) % MATRIX_NUM_ROWS;
    } else if (next_row >= MATRIX_NUM_ROWS) {
        next_row = next_row % MATRIX_NUM_ROWS;
    }

	// Column Wrapping:
	/* 
	Example: player_col = 5; delta_row = -7.
	player_col = 5 + (-7) = -2 (Past leftmost column by 2 --> we must move to 2nd row from the right).
	player_row = (-2 + 16) % 16 = 14 % 16 = 14 (Moved to 14th row --> 2nd from the right).
	*/
	int8_t next_col = player_col + delta_col;
    if (next_col < 0) {
        next_col = (next_col + MATRIX_NUM_COLUMNS) % MATRIX_NUM_COLUMNS;
    } else if (next_col >= MATRIX_NUM_COLUMNS) {
        next_col = next_col % MATRIX_NUM_COLUMNS;
    }

    // Check for diagonal movement.
    if (delta_row != 0 && delta_col != 0)
    {
        if (board[next_row][next_col] & BOX)
        {
            diagonal_box_message(); // Show the message for invalid diagonal box move.
            return false; // Block the move.
        }
    }

    if (delta_row != 0 && delta_col != 0) {
        if ((board[next_row][player_col] == WALL || board[next_row][player_col] == BOX) &&
            (board[player_row][next_col] == WALL || board[player_row][next_col] == BOX)) {
            printf(PSTR("Can't squeeze diagonally through!\n"));
            return false;
        }
    }

    // Check if player attempts to move into wall.
    if (!valid_move(delta_col, delta_row))
    {
		move_terminal_cursor(1, 1);
    	clear_to_end_of_line();
        // Becomes an invalid --> return false for counter to not increment.
        random_messages();
        return false;
    }

    was_box_shoved = false;

    // Check if player pushes box.
    if (board[next_row][next_col] & BOX)
    {
        // Row Wrapping (box):
        int8_t next_box_row = next_row + delta_row;
        if (next_box_row < 0) {
            next_box_row = (next_box_row + MATRIX_NUM_ROWS) % MATRIX_NUM_ROWS;
        } else if (next_box_row >= MATRIX_NUM_ROWS) {
            next_box_row = next_box_row % MATRIX_NUM_ROWS;
        }

        // Column Wrapping (box).
        int8_t next_box_col = next_col + delta_col;
        if (next_box_col < 0) {
            next_box_col = (next_box_col + MATRIX_NUM_COLUMNS) % MATRIX_NUM_COLUMNS;
        } else if (next_box_col >= MATRIX_NUM_COLUMNS) {
            next_box_col = next_box_col % MATRIX_NUM_COLUMNS;
        }

        // Case 2: Invalid move --> box cannot move due to wall --> to not increment counter.
        if (board[next_box_row][next_box_col] & WALL)
        {
			move_terminal_cursor(1, 1);
            clear_to_end_of_line();
            printf(PSTR("You cannot push the box into a wall.\n"));
            return false;
        }

        // Case 3: Invalid move --> box cannot move due to another box --> to not increment counter.
        // You can tell I moved the case 2 and case 3 messages from box_movement into move_player.
        if (board[next_box_row][next_box_col] & BOX)
        {
			move_terminal_cursor(1, 1);
    		clear_to_end_of_line();
            printf(PSTR("You cannot stack the boxes.\n"));
            return false;
        }

        if (board[next_row][next_col] & TARGET) {
            stop_fun_box_animation();
        }

        // If valid move --> reference helper function (makes simpler).
        box_movement(next_row, next_col, delta_row, delta_col);
        was_box_shoved = true;
	}			

    if (playing_animation)
    {
        if ((board[animation_box_row][animation_box_col] & BOX) == 0)
        {
            uint8_t tempx = animation_box_row;
            uint8_t tempy = animation_box_col;
            playing_animation = false;
            stop_fun_box_animation();
            paint_square(tempx, tempy);
        }
    }

    // Valid move --> update player position --> increment counter.
    player_row = next_row;
    player_col = next_col;

    player_visible = true;
    ledmatrix_update_pixel(player_row, player_col, COLOUR_PLAYER);


    if (delta_row != 0 && delta_col != 0)
    {
        was_diagonal = true;
    }
    
    // Update terminal for player.
    // `+5` adjusts whole terminal down to make room for messages and timer.
    move_terminal_cursor((MATRIX_NUM_ROWS - player_row) + 5, player_col * 2 + 1);
    set_display_attribute(BG_CYAN);  // Player colour --> I selected cyan.
    printf("  ");  // Draw player non-compressed.
    normal_display_mode(); // Basically reset --> this fixed the cyan error I had which unintentionally coloured my terminal cyan.
    store_move_int0_stack(delta_row, delta_col, was_box_shoved, was_diagonal);
    return true;
}

// Want to check if every target (row, col) has a box --> target without box = not game over.
// Return true if game over (will break out of game loop); return false if not game over.
bool is_game_over(void) {
	for (uint8_t row = 0; row < MATRIX_NUM_ROWS; row++) {
        for (uint8_t col = 0; col < MATRIX_NUM_COLUMNS; col++) {
			// Check if square = target ANDING check if square = no box.
            if ((board[row][col] & TARGET) && !(board[row][col] & BOX)) {
                return false;
            }
        }
    }
    paint_square(player_row, player_col);
    return true; // check if square = target ANDING Check if square = box.
}