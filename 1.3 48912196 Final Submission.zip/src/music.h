#ifndef MUSIC_H
#define MUSIC_H
#define NOTE_C7 2093 // High C (C7).

#include <stdint.h>
#include <stdbool.h>

// This was so cancer to learn what a struct was dear god.
// Struct includes --> frequency, duration, and top_value.
typedef struct {
    uint16_t frequency; // Note frequency (Hz); pitch.
    uint16_t duration; // Duration of note in (ms); note length.
    // uint16_t top_value; // T/C 1 top_value; generates note.
} Note;

// Extern variables.
extern volatile bool music_paused;
extern volatile uint8_t current_note_index;
extern volatile uint16_t note_duration_countdown;
extern volatile bool melody_loop;
extern volatile Note *current_melody;
extern volatile uint8_t current_melody_length;

// Array for the piece. Note, I will not be using the top_value in the struct for music.c.
// For some reason, it works despite me only putting the frequency and duration.
extern Note final_melody[];
extern const uint8_t final_melody_length;

extern Note start_melody[];
extern const uint8_t start_melody_length; 

extern Note ding_melody[];
extern const uint8_t ding_melody_length;

void init_music(void);
void setting_melody(Note *melody, uint8_t length, bool loop);
void resume_music(void);
void pause_music(void);

#endif