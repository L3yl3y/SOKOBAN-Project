#include <stdint.h>
#include <stdbool.h>

extern uint16_t step_count;
extern bool update;
