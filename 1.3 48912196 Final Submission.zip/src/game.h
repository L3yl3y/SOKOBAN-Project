#ifndef GAME_H_
#define GAME_H_

#include <stdint.h>
#include <stdbool.h>
#include "ledmatrix.h"

typedef struct {
	int8_t delta_row;
	int8_t delta_col;
	bool was_box_shoved;
    bool was_diagonal;
} movement;


typedef struct {
    uint8_t board[MATRIX_NUM_ROWS][MATRIX_NUM_COLUMNS];
} levelstruct;

#define ROOM       	(0U << 0)
#define WALL       	(1U << 0)
#define BOX        	(1U << 1)
#define TARGET     	(1U << 2)
#define OBJECT_MASK	(ROOM | WALL | BOX | TARGET)

// Colour definitions.
#define COLOUR_PLAYER	(COLOUR_DARK_GREEN)
#define COLOUR_WALL  	(COLOUR_YELLOW)
#define COLOUR_BOX   	(COLOUR_ORANGE)
#define COLOUR_TARGET	(COLOUR_RED)
#define COLOUR_DONE  	(COLOUR_GREEN)

void initialise_game(uint8_t level);
void load_game(uint8_t row, uint8_t col, levelstruct* lvl);


bool move_player(int8_t delta_row, int8_t delta_col);
bool is_game_over(void); // Changed return type to bool (was originally void).
void flash_player(void);
void flash_targets(void);
bool undo_moves(bool* was_diagonal);
bool redo_moves(bool* was_diagonal);

void store_in_redo_stack(movement move);

uint8_t (*get_board(void))[MATRIX_NUM_COLUMNS];

void do_animation(void);
void light_updating(void);

extern uint8_t player_row;
extern uint8_t player_col;
extern uint8_t board[MATRIX_NUM_ROWS][MATRIX_NUM_COLUMNS];

#endif
