#include "timer1.h"
#include <avr/io.h>
#include <avr/interrupt.h>

void init_timer1(void) {

    // Timer starts the count from zero.
    TCNT1 = 0;

    // Timer1 for PWM with prescalar 8 --> control music frequency (notes played by buzzer).
    // (1:0) Clear output on compare match.
    // (1:1:1:1) Fast PWM TOP OCR1A value.
    TCCR1A = (1 << COM1B1) | (1 << WGM11) | (1 << WGM10);
    TCCR1B = (1<<WGM13) | (1 << WGM12) | (1 << CS11);

    // Set dynamically based on the PWM note frequency.
    OCR1A = 0;
}