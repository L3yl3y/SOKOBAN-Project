#ifndef TIMER2_H_
#define TIMER2_H_

// Skeletal timer 2 initialisation function.
void init_timer2(void);

#endif /* TIMER2_H_ */
