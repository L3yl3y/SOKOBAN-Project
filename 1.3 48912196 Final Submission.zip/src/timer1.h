#ifndef TIMER1_H
#define TIMER1_H

void init_timer1(void);

#endif // TIMER1_H