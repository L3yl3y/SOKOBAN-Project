#include "buttons.h"
#include <stdint.h>
#include <stdbool.h>
#include <avr/io.h>
#include <avr/interrupt.h>

// Global variable to keep track of the last button state so that we
// can detect changes when an interrupt fires. The lower 4 bits (0 to 3)
// will correspond to the last state of port B pins 0 to 3.
static volatile uint8_t last_button_state;

// Our button queue. button_queue[0] is always the head of the queue. If we
// take something off the queue we just move everything else along. We don't
// use a circular buffer since it is usually expected that the queue is very
// short. In most uses it will never have more than 1 element at a time.
// This button queue can be changed by the interrupt handler below so we
// should turn off interrupts if we're changing the queue outside the handler.
#define BUTTON_QUEUE_SIZE 4
static volatile uint8_t button_queue[BUTTON_QUEUE_SIZE];
static volatile uint8_t queue_length;

void init_buttons(void)
{
	// Empty the button push queue and reset last state.
	queue_length = 0;
	last_button_state = 0;

	// Enable the interrupt (see datasheet page 77).
	PCICR |= (1 << PCIE1);
	
	// Make sure the interrupt flag is cleared (by writing a 
	// 1 to it) (see datasheet page 78).
	PCIFR |= (1 << PCIF1);
	
	// Choose which pins we're interested in by setting the relevant bits in the mask register (see datasheet page 78).
	PCMSK1 |= (1 << PCINT8) | (1 << PCINT9) | (1 << PCINT10) |
		(1 << PCINT11);
}

ButtonState button_pushed(void)
{
	ButtonState result = NO_BUTTON_PUSHED; // Default result.

	if (queue_length > 0)
	{
		// We turn off interrupts (if on) before we make any changes to the queue.
		// If interrupts were on, we turn them back on when done.
		result = button_queue[0];

		// Save whether interrupts were enabled and turn them off.
		bool interrupts_were_enabled = bit_is_set(SREG, SREG_I);
		cli();
		
		for (uint8_t i = 1; i < queue_length; i++)
		{
			button_queue[i - 1] = button_queue[i];
		}
		queue_length--;

		if (interrupts_were_enabled)
		{
			// Turn them back on again.
			sei();
		}
	}
	return result;
}

void clear_button_presses(void)
{
	// Save whether interrupts were enabled and turn them off.
	bool interrupts_were_enabled = bit_is_set(SREG, SREG_I);
	cli();
	queue_length = 0;
	last_button_state = 0;
	if (interrupts_were_enabled)
	{
		// Turn them back on again.
		sei();
	}
}

// Interrupt handler for a change on buttons.
ISR(PCINT1_vect)
{
	uint8_t button_state = PINB & 0x0F;
	for (uint8_t pin = 0; pin < NUM_BUTTONS; pin++)
	{
		if (queue_length < BUTTON_QUEUE_SIZE
				&& (button_state & (1 << pin))
				&& !(last_button_state & (1 << pin)))
				{
			button_queue[queue_length++] = pin;
		}
	}
	// Remember this button state.
	last_button_state = button_state;
}
