#include "music.h"
#include "timer1.h"
#include "timer2.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdbool.h>
#include <stdio.h>
#include "terminalio.h"
#include <avr/pgmspace.h>


// Notes from Ocatve 5 to 7.
#define NOTE_B5 988
#define NOTE_FS7 2960
#define NOTE_G7 3136
#define NOTE_CS7 2217
#define NOTE_E7 2637
#define NOTE_AS6 1865
#define NOTE_FS6 1480
#define NOTE_CS6 1109
#define NOTE_D6 2349
#define NOTE_A6 1760
#define NOTE_F6 1397
#define NOTE_C6 1047
#define NOTE_E6 1319
#define NOTE_CSH6 1109
#define NOTE_FS5 740
#define NOTE_AS5 933
#define NOTE_D7 2349
#define NOTE_G6 1568

#define NOTE_FS3 185
#define NOTE_F3 175
#define NOTE_CS3 139
#define NOTE_G5 784
#define NOTE_A5 880

// Note Durations (from crotchet to dotted minim).
#define CROTCHET_DURATION 110 // This is to adjust how fast you want to play the song; cynthia's theme.
#define MINIM_DURATION (CROTCHET_DURATION * 2)
#define DOTTED_MINIM_DURATION (MINIM_DURATION + (MINIM_DURATION / 2)) 

// FS2, FS2, FS2, FS5 dotted minim, F2, F2, F2, G5 dotted crotchet, CS2, CS2, CS2, F5 dotted minim, 
// FS2, FS2, FS2, FS5 dotted minim, FS3 dotted minim,
// E6, AS5, CS6, FS5, AS5, CS5, FS5, G5, FS5, E5, AS4, CS5, FS4, AS4, FS4, G4, A4, FS5, E5, CS5, AS4.
Note start_melody[] = {
    {NOTE_FS3, CROTCHET_DURATION}, {NOTE_FS3, CROTCHET_DURATION}, {NOTE_FS3, CROTCHET_DURATION}, {NOTE_FS6, DOTTED_MINIM_DURATION},
    {NOTE_F3, CROTCHET_DURATION}, {NOTE_F3, CROTCHET_DURATION}, {NOTE_F3, CROTCHET_DURATION}, {NOTE_G6, DOTTED_MINIM_DURATION},
    {NOTE_CS3, CROTCHET_DURATION}, {NOTE_CS3, CROTCHET_DURATION}, {NOTE_CS3, CROTCHET_DURATION}, {NOTE_F6, DOTTED_MINIM_DURATION},
    {NOTE_FS3, CROTCHET_DURATION}, {NOTE_FS3, CROTCHET_DURATION}, {NOTE_FS3, CROTCHET_DURATION}, {NOTE_FS6, DOTTED_MINIM_DURATION},
    {NOTE_FS3, DOTTED_MINIM_DURATION},
    {NOTE_E7, CROTCHET_DURATION}, {NOTE_AS6, CROTCHET_DURATION}, {NOTE_CS7, CROTCHET_DURATION}, {NOTE_FS6, CROTCHET_DURATION},
    {NOTE_AS6, CROTCHET_DURATION}, {NOTE_CS6, CROTCHET_DURATION}, {NOTE_FS6, CROTCHET_DURATION}, {NOTE_G6, CROTCHET_DURATION},
    {NOTE_FS6, CROTCHET_DURATION}, {NOTE_E6, CROTCHET_DURATION}, {NOTE_AS5, CROTCHET_DURATION}, {NOTE_CS6, CROTCHET_DURATION},
    {NOTE_FS5, CROTCHET_DURATION}, {NOTE_AS5, CROTCHET_DURATION}, {NOTE_FS5, CROTCHET_DURATION}, {NOTE_G5, CROTCHET_DURATION},
    {NOTE_A5, CROTCHET_DURATION}, {NOTE_FS6, CROTCHET_DURATION}, {NOTE_E6, CROTCHET_DURATION}, {NOTE_CS6, CROTCHET_DURATION},
    {NOTE_AS5, CROTCHET_DURATION}
};

// B4 dotted minim, F#4, A#4, C#5, E5, F#5, 
// G5, F#5, D5, C#5, B4, C5, C#5, F#4, A#4, C#5, F#5, A#5, C#6, E6, F#6, C#6, A#5, C#6, G5, F#5, F5, F#5, A#5, C#6, 
// E5, F#5, G5, E5, C#5, D5, A#4.
Note final_melody[] = {
    {NOTE_B5, DOTTED_MINIM_DURATION}, {NOTE_FS5, CROTCHET_DURATION},{NOTE_AS5, CROTCHET_DURATION}, 
    {NOTE_CS6, CROTCHET_DURATION}, {NOTE_E6, CROTCHET_DURATION}, {NOTE_FS6, CROTCHET_DURATION},
    {NOTE_G6, CROTCHET_DURATION}, {NOTE_FS6, CROTCHET_DURATION}, {NOTE_D6, CROTCHET_DURATION}, 
    {NOTE_CS6, CROTCHET_DURATION}, {NOTE_B5, CROTCHET_DURATION}, {NOTE_C6, CROTCHET_DURATION},
    {NOTE_CS6, CROTCHET_DURATION}, {NOTE_FS5, CROTCHET_DURATION}, {NOTE_AS5, CROTCHET_DURATION},
    {NOTE_CS6, CROTCHET_DURATION}, {NOTE_FS6, CROTCHET_DURATION}, {NOTE_AS6, CROTCHET_DURATION},
    {NOTE_CS7, CROTCHET_DURATION}, {NOTE_E7, CROTCHET_DURATION}, {NOTE_FS7, CROTCHET_DURATION},
    {NOTE_CS7, CROTCHET_DURATION}, {NOTE_AS6, CROTCHET_DURATION}, {NOTE_CS7, CROTCHET_DURATION},
    {NOTE_G6, CROTCHET_DURATION}, {NOTE_FS6, CROTCHET_DURATION}, {NOTE_F6, CROTCHET_DURATION},
    {NOTE_FS6, CROTCHET_DURATION}, {NOTE_AS6, CROTCHET_DURATION}, {NOTE_CS7, CROTCHET_DURATION},
    {NOTE_E6, CROTCHET_DURATION}, {NOTE_FS6, CROTCHET_DURATION}, {NOTE_G6, CROTCHET_DURATION},
    {NOTE_E6, CROTCHET_DURATION}, {NOTE_CS6, CROTCHET_DURATION}, {NOTE_D6, CROTCHET_DURATION},
    {NOTE_AS5, CROTCHET_DURATION},
};

Note ding_melody[] = {
    {NOTE_C7, 100}  // High C note for 100 ms
};

const uint8_t ding_melody_length = sizeof(ding_melody) / sizeof(Note);
const uint8_t final_melody_length = sizeof(final_melody) / sizeof(Note);
const uint8_t start_melody_length = sizeof(start_melody) / sizeof(Note);
volatile bool melody_loop = false;

volatile bool music_paused = false; // Music playback pause or not.
volatile uint8_t current_note_index = 0;
volatile uint16_t note_duration_countdown = 0;
volatile Note *current_melody = NULL;
volatile uint8_t current_melody_length = 0;

void setting_melody(Note *sound_name, uint8_t melody_length, bool loop) {
    current_melody = sound_name;
    current_melody_length = melody_length;
    current_note_index = 0;
    melody_loop = loop;

    // INSERTED!!!!!!!!!!!!!!!!!!
    note_duration_countdown = current_melody[current_note_index].duration;

    // INSERTED!!!!!!!!!!!!!!!!!!
    uint16_t frequency = current_melody[current_note_index].frequency;
    uint16_t toggle_interval = (F_CPU / (2 * 8 * frequency)) - 1; // Prescaler 8.
    OCR1A = toggle_interval; // Set toggle interval for Timer1.
    OCR1B = toggle_interval / 2; // 50% duty cycle.
}

void init_music(void) {
    init_timer1(); // PWM generation.
    init_timer2(); // Note timing.
    DDRD |= (1 << DDD4); // PD4 output for piezo buzzer.
    music_paused = true; // Start with music paused.
}

// Disable PWM output (T/C 1).
// Note, pause vs mute are same (just one is independnent of gameplay).
// I love you pause_music function --> so bloody helpful.
void pause_music(void) {
    music_paused = true; // This basically just iniates the pause.
    TCCR1A &= ~(1<<COM1B1); // Disable PWM output on OC1B pin.
}

void resume_music(void) {
    music_paused = false;
    TCCR1A |= (1<<COM1B1);
}

// I love interrupts so much.
// ISR triggered by T/C 2 Compare Match A event --> occurs every 1ms --> manages melody progression.
// Update note and duration in the melody.
ISR(TIMER2_COMPA_vect) {
    if (music_paused || current_melody == NULL) {
        return; // Exit ISR when paused so as to not go to the next note (also not resetting melody).
    }

    if (note_duration_countdown > 0) {
        note_duration_countdown--; // Play the note's durationn, and then once you finish the note...
    } else {
        // Move onto the next note and continue this...
        current_note_index++;
        if (current_note_index >= current_melody_length) {
            if (melody_loop) {
                // Reset to the beginning to loop the melody
                current_note_index = 0;
            } else {
                pause_music();
                current_melody = NULL;
                current_melody_length = 0;
                current_note_index = 0;
                note_duration_countdown = 0;
                return;
            }
        }

        // Update note duration countdown.
        note_duration_countdown = current_melody[current_note_index].duration;

        // Update frequency.
        uint16_t frequency = current_melody[current_note_index].frequency;
        uint16_t toggle_interval = (F_CPU / (2 * 8 * frequency)) - 1; // Prescaler 8.
        OCR1A = toggle_interval;
        OCR1B = toggle_interval * 50 / 100; // 50% duty cycle to have clear sounds that aren't gross.
    }
}