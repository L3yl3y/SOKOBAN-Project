#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <stdbool.h>

#include <util/delay.h>

#include "game.h"
#include "startscrn.h"
#include "ledmatrix.h"
#include "buttons.h"
#include "serialio.h"
#include "terminalio.h"
#include "timer0.h"
#include "timer1.h"
#include "timer2.h"
#include "music.h"
#include "project.h"
#include <avr/eeprom.h>

// Range within values (from ED discussion yufeng post) --> outside range movements are disregarded.
#define DEADZONE_LOW  340
#define DEADZONE_HIGH 682

static bool restarted = false;
static bool next_lvl = false;

uint8_t x_or_y = 0;
uint16_t value;
bool update = false;

// Other global variables --> set 0 since doesn't matter.
uint16_t step_count = 0; // No. valid moves made by player.
uint32_t time_spent = -1; // Total time spent (during gameplay).
static uint8_t current_level = 1;
static bool should_load_game = false;
uint8_t level = 0;
bool is_muted = false;

// Function prototypes.
void initialise_hardware(void);
void start_screen(void);
void new_game(void);
void play_game(void);
void handle_game_over(void);
void EEPROM_write(unsigned int Address, unsigned char Data);
unsigned char EEPROM_read(unsigned int Address);
void loading_the_game(uint8_t* player_row, uint8_t* player_col, uint8_t* current_level, levelstruct* lvl, uint16_t* steps, uint32_t* lvl_time);
void saving_the_game(void);
void delete_progress(void);

/////////////////////////////// main //////////////////////////////////
int main(void)
{
	// Setup hardware and callbacks; this will turn on interrupts.
	initialise_hardware();

	// Show start screen --> returns when player starts game.
	// This is super important --> sets up the concent of being able to inplement lvl 1 and lvl 2.

	// Loop forever and continuously play game.
	while (1)
	{
		if (!restarted && !next_lvl)
		{
			start_screen();
		}
		new_game(); // This is where we can implement the selected level.
		restarted = false;
		next_lvl = false;
		play_game();
		resume_music();
	}
}

// Updates seven-segment display based on current step count.
// 'Count' -->  represents number displayed on SSD.
void update_ssd_display(uint8_t count);

void initialise_hardware(void)
{
	init_ledmatrix();
	init_buttons();
	init_serial_stdio(19200, false);

	// Initialise SSD here (so DDRC and DDRD).
	// Port C output (for all SSD segments).
	// Port D output (CC bit).
	DDRC = 0xFF;
	DDRD |= (1 << PD2);

	// Joystick --> review labs Week 10 Serial communications --> take a lot of inspiration from lab 16.
	ADMUX = (1 << REFS0); // AVCC with external capacitor at AREF pin (from sheet).
	ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1); // ADC control and status register (prescalar 64).

	init_timer0();
	init_timer1();
	init_timer2();
	init_music();
	pause_music();

	// Turn on global interrupts.
	sei();
}

// JOYSTICK!!!!
// Captures joystick by reading analog values (X or Y).
// Take a lot of inspiration from the Lab.
uint16_t read_adc() {
	// ADC mux --> choose ADC0 if x_or_y is 0, ADC1 if x_or_y is 1.
	if(x_or_y == 0) {
		ADMUX &= ~1; // ADC0 for X-axis.
		} else {
		ADMUX |= 1; // ADC1 for Y-axis.
	}
	// Start ADC conversion.
	ADCSRA |= (1<<ADSC);
	
	while(ADCSRA & (1<<ADSC)) {
	}
	value = ADC;
	// Next time through loop --> do other direction.
	x_or_y ^= 1;
	return ADC;
}

// Lmao, has a lot more code in it than I anticipated.
void start_screen(void)
{
	bool game_to_load = false;
	pause_music();

	// Start start_melody if not muted.
    if (!is_muted) {
        setting_melody(start_melody, start_melody_length, true);
        resume_music();
    }

	update = false;
	PORTC = 0;
	PORTD ^= (1 << 2);
	
	// Hide terminal cursor and set display mode to default.
	hide_cursor();
	normal_display_mode();

	// Clear terminal screen and output title ASCII art.
	clear_terminal();
	display_terminal_title(3, 5);
	move_terminal_cursor(11, 5);

	// Has been changed to my name; not including the chevrons.
	printf_P(PSTR("CSSE2010/7201 Project by Leyla Suljic - 48912196"));

	// Setup start screen on LED matrix.
	setup_start_screen();

	// Clear button presses registered as a result of powering on I/O board.
	// This is to work around minor hardware limitation.
	// This is to ensure start screen is not skipped when you power the I/O board.
	clear_button_presses();


	uint8_t sig = 100;

	if (eeprom_read_byte((uint8_t*)0) == sig)
	{
		game_to_load = true;
		move_terminal_cursor(13, 15);
		printf_P(PSTR("Press 'r'/'R' to load game"));
		move_terminal_cursor(14, 14);
		printf_P(PSTR("Press 'd'/'D' to delete game"));
	}

	// Wait until a button is pushed or 's'/'S' is entered.
	while (1)
	{
		// Check for button presses.
		// If button is pressed --> exit start screen by breaking out of this infinite loop.
		if (button_pushed() != NO_BUTTON_PUSHED)
		{
			pause_music();
			break; // PP: Was an error I had, but allows game 1 to be called at any button press.
		}

		// If no button is pressed --> check if we have terminal inputs.
		if (serial_input_available())
		{
			// Terminal input is available --> get which character.
			int serial_input = fgetc(stdin);

			// If input is 's'/'S' --> start screen by breaking out of this loop.
			// Note, I am using the given S logic and the previous button presses as inspiration for the W, A, S, D terminal inputs.
			// PP: I have learnt --> do not hangle player movement in the start_screen() function.
			if (serial_input == 's' || serial_input == 'S')
			{
				pause_music();
				current_level = 1; // Will always start the game at level 1 upon starting the game (no jumping to game 2).
				break;
			}

			if (serial_input == '2')
			{
				pause_music();
				current_level = 2; // This reads when the user inputs 2 after completing the first level.
				break;
			}

			if (toupper(serial_input) == 'R' && game_to_load)
			{
				should_load_game = true;
				current_level = 1;
				break;
			}

			if (toupper(serial_input) == 'D' && game_to_load)
			{
				game_to_load = false;
				EEPROM_write(0, 0);

				move_terminal_cursor(13, 15);
				clear_to_end_of_line();

				move_terminal_cursor(14, 14);
				clear_to_end_of_line();
			}

			// Check for mute/unmute input (copy from where I'd done it during gameplay).
			// As dude on E.D said --> there should be no music that is unpausable/unmute-able.
            if (serial_input == 'q' || serial_input == 'Q') {
            	is_muted = !is_muted;

                if (is_muted){
                    pause_music();
                }
                else {
                    resume_music();
                }
			}	
		}
		// No button presses + no 's'/'S' typed into the terminal:
		// We will loop back and do checks again.
		// We also update start screen animation on LED matrix.
		update_start_screen();
	}
}

void new_game(void)
{
	pause_music();
	hide_cursor();
	clear_terminal();

	if (should_load_game)
	{
		uint8_t player_row;
		uint8_t player_col;
		levelstruct lv;
		loading_the_game(&player_row, &player_col, &current_level, &lv, &step_count, &time_spent);
		load_game(player_row, player_col, &lv);
		delete_progress();

		should_load_game = false;
	}
	else
	{
		time_spent = -1;
		initialise_game(current_level);
	}

	// Clear all button presses and serial inputs.
	// Remove button presses that occur before new game starts.
	clear_button_presses();
	clear_serial_input_buffer();
}

void play_game(void)
{
	pause_music();
	// Upon starting actual gameplay --> play background music.
	
	uint32_t time = get_current_time();
	uint32_t last_flash_time = time;
	uint32_t last_ssd_time = time; // Reference point when SSD was last updated.
	uint32_t last_timer_time = time - 1000;
	bool paused = false; // Pause flag.
	update = true;

	move_terminal_cursor(4, 1);
	printf_P(PSTR("Level: %d "), current_level);
	
	// Joystick variables (ADC thresholds movement direction).
	const uint16_t THRESHOLD_HIGH = DEADZONE_HIGH;
    const uint16_t THRESHOLD_LOW  = DEADZONE_LOW;
    uint32_t last_joystick_time = get_current_time();
	
	// Game loop --> runs as long as the game is not over.
	// In loop --> I am tasked to check for button presses + take action based on which buttons pressed.
	while (!is_game_over())
	{
		/*
		ButtonState btn --> checks current state of the button.
		Meaning:
		= NO_BUTTON_PUSHED --> returns no button pressed.
		= BUTTON0_PUSHED --> returns button 0 pressed.
		etc...
		*/
		uint32_t current_time = get_current_time();
		ButtonState btn = button_pushed();


		if (current_time >= last_ssd_time)
        {
            update_ssd_display(step_count);
            last_ssd_time = current_time;
        }
		// Move player --> see move_player(...) in game.c.
		// (0, 1) in move_player represents direction --> (row, column).
		// Hint: Remember to reset the flash cycle here (so just last_flash_time = get_current_time();).
		// In some sense --> it keeps the fashing in sync.
		// Note, to move player with terminal --> combine with previous button presses + take inspiration of serial_input commands.
		int serial_input = -1;
		if (serial_input_available())
		{
			serial_input = fgetc(stdin);
		}

		if (toupper(serial_input) == 'Q' || serial_input == 'q')
        {
            is_muted = !is_muted;
            if (is_muted)
            {
                pause_music();
            }
            else
            {
                if (current_melody != NULL) {
            		resume_music();
        		}
            }
        }

		// GAMEPLAY PAUSE !!!!!!!!!!!!!!!!!!!!!!!!
		// Check for pausing/unpausing game regardless of serial_input.
		// Note, task sheet requires music to be paused too upon serial input p.
        if (serial_input == 'p' || serial_input == 'P')
        {
            paused = !paused; // Toggle paused state.
            if (paused)
            {
                normal_display_mode();
                move_terminal_cursor(15, 1);
                printf_P(PSTR("Game paused; press p/P to continue."));

				move_terminal_cursor(16, 1);
                printf_P(PSTR("Press x/X to exit."));

				pause_music();
            }
            else
            {
				move_terminal_cursor(15, 1);
				clear_to_end_of_line();
				move_terminal_cursor(16, 1);
				clear_to_end_of_line();
				pause_music();
            }
        }

		// If game is paused, freeze gameboard but allow SSD updates.
        if (paused)
        {
			if (toupper(serial_input) == 'X')
			{
				clear_terminal();
				move_terminal_cursor(2, 1);
				printf_P(PSTR("Press y to save"));
				move_terminal_cursor(3, 1);
				printf_P(PSTR("Press n to not save"));

				while(1)
				{
					int serial_input = -1;
					if (serial_input_available())
					{
						serial_input = fgetc(stdin);
					}

					if (toupper(serial_input) == 'Y')
					{
						saving_the_game();
						return;
					}
					if (toupper(serial_input) == 'N')
					{
						return;
					}
				}

				return;
				saving_the_game();
			}
            // Skip loop while paused.
            continue;
        }

		do_animation();
		flash_targets();
		light_updating();

		// Handle undo via 'z' or 'Z'.
        if (toupper(serial_input) == 'Z')

        {
			bool was_diagonal;
            if (undo_moves(&was_diagonal)) {
                if (step_count > 0)
				{
					if(was_diagonal)
					{
						step_count--;
					}

					step_count--;
				}
            } else {
				continue;
            }
        }

		if (toupper(serial_input) == 'Y')
		{
			bool was_diagonal;

			redo_moves(&was_diagonal);

			if (was_diagonal)
			{
				step_count++;
			}
			step_count++;
		}

        // Update SSD every 10ms when game is unpaused.
		// You'll notice I copied and pasted this again, it allows it to continue multiplexing.
		
		// Joystick controls (need and x and y since 2D).
        int8_t move_x = 0;
        int8_t move_y = 0;

		// Added 200ms delay or something otherwise it's SPEEDDDDD (player flies bahah).
        if (current_time >= last_joystick_time + 200) {
            // Read X from ADC0.
            uint16_t x_value = read_adc(); // A0.

            // Read Y from ADC1.
            uint16_t y_value = read_adc(); // A1.

			// The next following lines just define the direction of the player movement relative to the joystick.
            if (x_value > THRESHOLD_HIGH) {
                move_x = 1; // Right.
            }
            else if (x_value < THRESHOLD_LOW) {
                move_x = -1; // Left.
            }

            if (y_value > THRESHOLD_HIGH) {
                move_y = 1; // Down.
            }
            else if (y_value < THRESHOLD_LOW) {
                move_y = -1; // Up.
            }

            last_joystick_time = current_time;
        }
        // End joystick controls.

		if (btn == BUTTON0_PUSHED || serial_input == 'd' || serial_input == 'D')
		{
			// Button 0 => Right.
			move_x = 1;
		}

		else if (btn == BUTTON1_PUSHED || serial_input == 's' || serial_input == 'S')
		{
			// Button 1 => Down.
			move_y = -1;
		}

		else if (btn == BUTTON2_PUSHED || serial_input == 'w' || serial_input == 'W')
		{
			// Button 2 => Up.
			move_y = 1;
		}

		else if (btn == BUTTON3_PUSHED || serial_input == 'a' || serial_input == 'A')
		{
			// Button 3 => Left.
			move_x = -1;
		}

		current_time = get_current_time();


		// If variable created = true (i.e., player successfully moved) --> increase step counter.
		if (move_x != 0 || move_y != 0) {
            bool result = move_player(move_y, move_x); // Assuming move_player(y, x).
            if (result) {
				last_flash_time = current_time;

				if(move_x != 0 && move_y !=0){
					step_count++;
				}
                step_count++;
            }
        }

		if (current_time >= last_flash_time + 200)
		{
			// The moment current time is greater than last_flash_time + 200ms --> flash player (toggle visibility).
			flash_player();

			// Update last_flash_time with current_time (allows for repeating flash cycle).
			last_flash_time = current_time;
		}

		if (current_time >= last_timer_time + 1000) // I took inspiration from a lot of the other functions similar to this.
		{
			time_spent += 1;
			normal_display_mode(); // Black background --> just in case.
			move_terminal_cursor(3, 1);
			printf_P(PSTR("Time spent: %lu seconds   "), time_spent);

			// Update last_flash_time with current_time (allows for repeating flash cycle).
			last_timer_time = current_time;
		}
	}
	
	pause_music(); // 'Pause' music but it means to actually stop it.
	update_ssd_display(step_count); // Call to display the final step count statically.
	handle_game_over();
}

// This was given in the documentary --> max function doesn't exist so I hardcoded it.
// Score = max (200 – S , 0) × 20 + max (1200 – T , 0).
int32_t calculate_score(uint32_t step_count, uint32_t total_time)
{
    uint32_t max_steps_part; // Max Steps (first part of equation).
    uint32_t max_time_part; // Max Time (second part of equation).

	// Fewer Steps = better.
    if (step_count > 200){
        max_steps_part = 0;
    } else {
        max_steps_part = (200 - step_count) * 20;  // Reward for steps under 200.
    }

	// Lower time = better.
    if (total_time > 1200){
        max_time_part = 0;
    } else {
        max_time_part = 1200 - total_time; // Reward for time under 1200 seconds.
    }

    uint32_t score = max_steps_part + max_time_part; // Basically for function given to us --> I seperated it into 2 aspects.
    return score; // Return --> final calculated score.
}

void handle_game_over(void)
{
	clear_terminal();

	// Start final_melody if not muted.
    if (!is_muted) {
        setting_melody(final_melody, final_melody_length, true);
        resume_music();
    }

	uint32_t score = calculate_score(step_count, time_spent);

	// Literaly boring trial and error and padding spaces for victory screen.
	move_terminal_cursor(3, 0);
	normal_display_mode();
	printf("+================================================================+\n");

	move_terminal_cursor(4, 0);
	printf("|                         LEVEL COMPLETE                         |\n");

	move_terminal_cursor(5, 0);
	printf("|================================================================|\n");

	move_terminal_cursor(6, 0);
	printf("| Time:  %-2lus                                     Score: %-6lu   |\n", time_spent, score);

	move_terminal_cursor(7, 0);
	printf("| Steps: %-4u                                                    |\n", step_count);

	move_terminal_cursor(8, 0);
	printf("|================================================================|\n");

	move_terminal_cursor(9, 0);
	printf("|  [R] Restart Level   |   [N] Next Level   |   [E] Exit Game    |\n");

	move_terminal_cursor(10, 0);
	printf("+================================================================+\n");

	// Do nothing until a valid input is made.
	while (1)
	{		
		// Get serial input. If no serial input is ready, serial_input would be -1 (not a valid character).
		int serial_input = -1;
		if (serial_input_available())
		{
			serial_input = fgetc(stdin);
		}

		if (toupper(serial_input) == 'R')
		{
			// Restart game.
			restarted = true;
			step_count = 0;
			pause_music();
			break;
		}
		else if (toupper(serial_input) == 'E')
		{
			// Exit game.
			step_count = 0;
			pause_music();
			break;
		} 
		else if (toupper(serial_input) == 'N')
		{
			next_lvl = true;
			pause_music();
			current_level = 2; // Since there are no other games --> next game takes us straight to level 2 regardless.
			// Clear serial terminal.
			step_count = 0;
			break;
		}
		else if (serial_input == 'q' || serial_input == 'Q') // Copy as I'd done in gameplay and startscreen.
        {
            is_muted = !is_muted;

            if (is_muted){
            pause_music(); // Mute the music.
            }
            else {
            resume_music();
			}
		}
	}
}

void delete_progress(void)
{
	uint8_t a = 0;
	eeprom_update_byte((uint8_t*) 0, a);
}

void saving_the_game(void) {
	uint8_t a = 100;

	uint16_t eeprom_addr = 0;

    eeprom_update_byte((uint8_t*) eeprom_addr, a);
	eeprom_addr += sizeof(uint8_t);

	eeprom_update_byte((uint8_t*) eeprom_addr, current_level);
	eeprom_addr += sizeof(uint8_t);

	eeprom_update_byte((uint8_t*) eeprom_addr, player_row);
	eeprom_addr += sizeof(uint8_t);

	eeprom_update_byte((uint8_t*) eeprom_addr, player_col);
	eeprom_addr += sizeof(uint8_t);

	eeprom_update_word((uint16_t*) eeprom_addr, step_count);
	eeprom_addr += sizeof(uint16_t);

	eeprom_update_dword((uint32_t*) eeprom_addr, time_spent);
	eeprom_addr += sizeof(uint32_t);
	
	eeprom_update_block((const void*)get_board(), (void*)(eeprom_addr), sizeof(board));
}

void loading_the_game(uint8_t* player_row, uint8_t* player_col, uint8_t* current_level, levelstruct* lvl, uint16_t* steps, uint32_t* lvl_time) {
	uint16_t eeprom_addr = sizeof(uint8_t);

	*current_level = eeprom_read_byte((uint8_t*)eeprom_addr);
	eeprom_addr += sizeof(uint8_t);

	*player_row = eeprom_read_byte((uint8_t*)eeprom_addr);
	eeprom_addr += sizeof(uint8_t);

	*player_col = eeprom_read_byte((uint8_t*)eeprom_addr);
	eeprom_addr += sizeof(uint8_t);

	*steps = eeprom_read_word((uint16_t*)eeprom_addr);
	eeprom_addr += sizeof(uint16_t);

	*lvl_time = eeprom_read_dword((uint32_t*) eeprom_addr);
	eeprom_addr += sizeof(uint32_t);

	eeprom_read_block((void*)&lvl->board, (const void*)(eeprom_addr), sizeof(lvl->board));
}

void EEPROM_write(unsigned int Address, unsigned char Data) {
while(EECR & (1 << EEPE));
EEAR = Address;
EEDR = Data;
EECR |= (1 << EEMPE);
EECR |= (1 << EEPE);
}

unsigned char EEPROM_read(unsigned int Address) {
while(EECR & (1<<EEPE));
EEAR = Address;
EECR |= (1 << EERE);
return EEDR;
}