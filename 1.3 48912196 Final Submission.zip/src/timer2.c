#include "timer2.h"
#include <avr/io.h>
#include <avr/interrupt.h>

// Timer2 for the note timing (CTC mode) --> Bradely stone advice.
// Interrupt every ~1ms.
void init_timer2(void) {
    TCCR2A = (1 << WGM21); // CTC mode (0:1:0:0).
    TCCR2B = (1 << CS22); // Prescaler = 256 (1:0:0).

    // OCR2A for ~1ms interrupt --> F_CPU = 8MHz.
    OCR2A = 124; // (8,000,000 / (64 * 1000)) - 1 = 124.

    // Bit 1 – OCIE2A: Timer/Counter2 Output Compare Match A Interrupt Enable.
    TIMSK2 = (1 << OCIE2A);
}